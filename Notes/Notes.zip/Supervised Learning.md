# Regression Method

[Linear Regression](Linear%20Regression.md)

[Linear Classification](Linear%20Classification.md)

[Polynomial Regression](Polynomial%20Regression.md)

[Ridge Regression](Ridge%20Regression.md)

[[Logistic Regression]]

# Tools

[Gradient Descent](Gradient%20Descent.md)
